﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroovesEndMusicPitcherScript : MonoBehaviour {

    AudioSource a = null;
    float masterPitch = 1f;
    int goalPitch = 1;

    void Start() {
        if(a == null) {
            a = za.skald.GetComponent<AudioSource>();
            return;
        }

        if (xa.player && a != null) {
              if(xa.playerPos.x > 823) {
                goalPitch = 0;
                masterPitch = 0;
                a.pitch = 0;
            } else {
                goalPitch = 1;
                masterPitch = 1;
                a.pitch = 1;
            }
        }
    }

	void Update () {
        
        if (xa.player && a != null) {
            
            if(xa.playerPos.x > 823) {
                goalPitch = 0;
            } else {
                goalPitch = 1;
            }

            if(masterPitch > goalPitch) { masterPitch -= fa.deltaTime/2; }
            else if(masterPitch < goalPitch) { masterPitch += fa.deltaTime/2; }

            if(masterPitch > 1) { masterPitch = 1; }
            else if(masterPitch < 0) { masterPitch = 0; }

            a.pitch = masterPitch;
        }		
	}
}
